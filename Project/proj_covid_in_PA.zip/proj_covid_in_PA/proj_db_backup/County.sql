create table County
(
    county_Name     varchar(20) null,
    Population      int         null,
    democratic_Vote int         null,
    republican_Vote int         null,
    represent_Party varchar(5)  null,
    county_FIPS     int         null
);

INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Adams', 103009, 19268, 39914, 'rep', 42001);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Allegheny', 1216045, 528468, 260535, 'demo', 42003);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Armstrong', 64735, 12470, 25307, 'rep', 42005);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Beaver', 163929, 51167, 46397, 'demo', 42007);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Bedford', 47888, 6491, 23090, 'rep', 42009);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Berks', 421164, 113136, 108156, 'demo', 42011);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Blair', 121829, 20756, 47133, 'rep', 42013);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Bradford', 60323, 8809, 23545, 'rep', 42015);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Bucks', 628270, 202939, 192709, 'demo', 42017);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Butler', 187853, 40140, 75823, 'rep', 42019);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Cambria', 130192, 35769, 40621, 'rep', 42021);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Cameron', 4447, 870, 1761, 'rep', 42023);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Carbon', 64182, 15848, 20895, 'demo', 42025);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Centre', 162385, 44125, 42191, 'demo', 42027);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Chester', 524989, 154936, 149871, 'demo', 42029);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Clarion', 38438, 6334, 14576, 'rep', 42031);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Clearfield', 79255, 14380, 28294, 'rep', 42033);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Clinton', 38632, 7214, 11861, 'rep', 42035);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Columbia', 64964, 12855, 19760, 'rep', 42037);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Crawford', 84629, 16566, 29589, 'rep', 42039);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Cumberland', 253370, 62735, 89730, 'rep', 42041);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Dauphin', 278299, 86749, 74170, 'demo', 42043);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Delaware', 566747, 201914, 150988, 'demo', 42045);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Elk', 29910, 7098, 10716, 'rep', 42047);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Erie', 269728, 85602, 67064, 'demo', 42049);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Fayette', 129274, 36871, 34492, 'demo', 42051);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Forest', 7247, 1030, 1944, 'rep', 42053);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Franklin', 155027, 23814, 60044, 'rep', 42055);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Fulton', 14530, 1918, 6877, 'rep', 42057);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Greene', 36233, 9409, 10461, 'rep', 42059);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Huntingdon', 45144, 7235, 18024, 'rep', 42061);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Indiana', 84073, 16206, 26495, 'rep', 42063);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Jefferson', 43425, 6584, 18330, 'rep', 42065);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Juniata', 24763, 3092, 9489, 'rep', 42067);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lackawanna', 209674, 82432, 45822, 'demo', 42069);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lancaster', 545724, 112153, 176014, 'rep', 42071);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lawrence', 85512, 22792, 26390, 'rep', 42073);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lebanon', 141793, 26596, 49828, 'rep', 42075);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lehigh', 369318, 114225, 82473, 'demo', 42077);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Luzerne', 317417, 95189, 81275, 'demo', 42079);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Lycoming', 113299, 19782, 41751, 'demo', 42081);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('McKean', 40625, 6080, 15419, 'rep', 42083);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Mercer', 109424, 27382, 34916, 'rep', 42085);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Mifflin', 46138, 6126, 17300, 'rep', 42087);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Monroe', 170271, 51863, 38881, 'demo', 42089);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Montgomery', 830915, 297305, 203863, 'demo', 42091);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Montour', 18230, 4131, 6280, 'rep', 42093);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Northampton', 305285, 97999, 79075, 'demo', 42095);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Northumberland', 90843, 18830, 30612, 'demo', 42097);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Perry', 46272, 6325, 19456, 'rep', 42099);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Philadelphia', 1584064, 802291, 115844, 'demo', 42101);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Pike', 55809, 14129, 20014, 'rep', 42103);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Potter', 16526, 2103, 7648, 'rep', 42105);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Schuylkill', 141359, 28735, 47881, 'rep', 42107);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Snyder', 40372, 4990, 14879, 'rep', 42109);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Somerset', 73447, 13008, 30642, 'rep', 42111);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Sullivan', 6066, 1267, 2603, 'rep', 42113);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Susquehanna', 40328, 6984, 16105, 'rep', 42115);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Tioga', 40591, 5607, 16979, 'rep', 42117);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Union', 44923, 7742, 13812, 'rep', 42119);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Venango', 50668, 9254, 18853, 'rep', 42121);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Warren', 39191, 7735, 14615, 'rep', 42123);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Washington', 206865, 59504, 65227, 'rep', 42125);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Wayne', 51361, 9545, 19693, 'rep', 42127);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Westmoreland', 348899, 97816, 118426, 'rep', 42129);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('Wyoming', 26794, 5052, 10540, 'rep', 42131);
INSERT INTO project.County (county_Name, Population, democratic_Vote, republican_Vote, represent_Party, county_FIPS) VALUES ('York', 449058, 98445, 157209, 'rep', 42133);