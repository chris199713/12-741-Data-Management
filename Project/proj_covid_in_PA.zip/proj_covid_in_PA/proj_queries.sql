USE project;

SELECT
    Vax.county_Name,
    SUM(Vax.fully_Vaxed) AS fully_Vaxed,
    County.Population,
    SUM(Vax.fully_Vaxed)/County.Population
        AS Vax_Rate, County.represent_Party
FROM Vax
INNER JOIN County
    ON Vax.county_Name=County.county_Name
GROUP BY Vax.county_Name
ORDER BY Vax_Rate DESC;

SELECT
    Cases.county_Name,
    1-SUM(Cases.Deaths)/SUM(Cases.Hospitalized)
        AS recovery_Rate
FROM Cases
GROUP BY Cases.county_Name
ORDER BY recovery_Rate DESC
LIMIT 10;


SELECT
       Cases.county_Name,
       Cases.Record_Date,
       Cases.New_case,
       Cases.Hospitalized,
       Cases.Deaths,
       Vax.fully_Vaxed
FROM Cases INNER JOIN Vax
ON Vax.county_Name = Cases.county_Name
AND Vax.Record_Date = Cases.Record_Date
WHERE Cases.county_Name='Montour' OR
Cases.county_Name='Washington' OR
Cases.county_Name='Indiana' OR
Cases.county_Name='Philadelphia'
ORDER BY Cases.county_Name, Cases.Record_Date;